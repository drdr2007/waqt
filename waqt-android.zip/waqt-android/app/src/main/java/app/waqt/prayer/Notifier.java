package app.waqt.prayer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;

/** Builds and posts the prayer, reminder and alarm notifications. */
final class Notifier {
    static final String CH_ADHAN = "adhan", CH_ALARM = "alarm", CH_REMIND = "remind";
    static final int ID_MAIN = 4001, ID_REMIND = 4002;

    static void ensureChannels(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        Prefs p = new Prefs(c);
        Tx.init(p);
        NotificationChannel a = new NotificationChannel(CH_ADHAN, Tx.L("الأذان والصلوات", "Adhan and prayers"), NotificationManager.IMPORTANCE_HIGH);
        a.setSound(null, null);
        a.enableVibration(false);
        NotificationChannel b = new NotificationChannel(CH_ALARM, Tx.L("منبّه الفجر", "Fajr alarm"), NotificationManager.IMPORTANCE_HIGH);
        b.setSound(null, null);
        b.enableVibration(false);
        NotificationChannel r = new NotificationChannel(CH_REMIND, Tx.L("تذكير قبل الصلاة", "Early reminder"), NotificationManager.IMPORTANCE_DEFAULT);
        nm.createNotificationChannel(a);
        nm.createNotificationChannel(b);
        nm.createNotificationChannel(r);
    }

    static Notification build(Context c, int type, int idx, boolean withStop) {
        Prefs p = new Prefs(c);
        Tx.init(p);
        boolean alarm = type == Scheduler.TYPE_ALARM;
        String channel = alarm ? CH_ALARM : (type == Scheduler.TYPE_PRE ? CH_REMIND : CH_ADHAN);
        Times.Day d = Times.day(p, 0);
        String title;
        String text;
        if (alarm) {
            title = "sahoor".equals(p.s("alType", "fajr")) ? Tx.L("وقت السحور", "Sahoor time") : Tx.L("استيقظ! اقترب الفجر", "Wake up! Fajr is near");
            text = Tx.pr(0) + " " + Tx.clock(d.mins[0]);
        } else if (type == Scheduler.TYPE_PRE) {
            title = Tx.pr(idx) + " " + Tx.L("بعد", "in") + " " + Tx.n(p.i("preMin", 10)) + " " + Tx.L("دقيقة", "min");
            text = Tx.clock(d.mins[idx]);
        } else {
            title = Tx.L("حان وقت صلاة ", "It is time for ") + Tx.pr(idx);
            text = Tx.clock(d.mins[idx]);
        }
        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(c, channel)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(!withStop)
            .setOngoing(withStop)
            .setCategory(alarm ? Notification.CATEGORY_ALARM : Notification.CATEGORY_REMINDER)
            .setVisibility(Notification.VISIBILITY_PUBLIC);
        if (withStop) {
            Intent stop = new Intent(c, AdhanService.class).setAction(AdhanService.ACT_STOP);
            PendingIntent sp = PendingIntent.getService(c, 11, stop, PendingIntent.FLAG_IMMUTABLE);
            b.addAction(new Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_stat), Tx.L("إيقاف", "Stop"), sp).build());
            if (alarm) {
                Intent snooze = new Intent(c, AdhanService.class).setAction(AdhanService.ACT_SNOOZE);
                PendingIntent zp = PendingIntent.getService(c, 12, snooze, PendingIntent.FLAG_IMMUTABLE);
                b.addAction(new Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_stat), Tx.L("غفوة", "Snooze"), zp).build());
                Intent full = new Intent(c, AlarmActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                b.setFullScreenIntent(PendingIntent.getActivity(c, 13, full, PendingIntent.FLAG_IMMUTABLE), true);
            }
        }
        return b.build();
    }

    /** Silent or reminder notification that needs no service. */
    static void post(Context c, int type, int idx) {
        ensureChannels(c);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(type == Scheduler.TYPE_PRE ? ID_REMIND : ID_MAIN, build(c, type, idx, false));
    }
}
