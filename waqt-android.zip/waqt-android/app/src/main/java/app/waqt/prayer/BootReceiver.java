package app.waqt.prayer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Sets the alarms again after a restart, an app update, or a time or time zone change. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        Scheduler.scheduleNext(c);
        WidgetProvider.refresh(c);
    }
}
