package app.waqt.prayer;

import java.time.DayOfWeek;
import java.time.Month;
import java.time.format.TextStyle;
import java.util.Locale;

/** Language and number helpers shared by every screen. */
final class Tx {
    static boolean ar = true;
    static boolean arDigits = true;
    static boolean h24 = false;

    static final String[] HM_AR = {"محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"};
    static final String[] HM_EN = {"Muharram", "Safar", "Rabi' I", "Rabi' II", "Jumada I", "Jumada II", "Rajab", "Sha'ban", "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah"};
    static final String[] PR_AR = {"الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء"};
    static final String[] PR_EN = {"Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"};

    static void init(Prefs p) {
        ar = "ar".equals(p.s("lang", "ar"));
        arDigits = p.b("digits", true);
        h24 = p.b("h24", false);
    }

    static String L(String a, String e) {
        return ar ? a : e;
    }

    static Locale loc() {
        return ar ? new Locale("ar") : Locale.ENGLISH;
    }

    static String n(String s) {
        if (!(ar && arDigits)) return s;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            b.append(c >= '0' && c <= '9' ? (char) ('٠' + (c - '0')) : c);
        }
        return b.toString();
    }

    static String n(int v) {
        return n(String.valueOf(v));
    }

    static String pr(int k) {
        return (ar ? PR_AR : PR_EN)[k];
    }

    static String hm(int m) {
        return (ar ? HM_AR : HM_EN)[Math.max(0, Math.min(11, m - 1))];
    }

    static String gMonth(int m) {
        return Month.of(m).getDisplayName(TextStyle.FULL_STANDALONE, loc());
    }

    static String weekday(DayOfWeek d) {
        return d.getDisplayName(TextStyle.FULL, loc());
    }

    static String weekdayShort(DayOfWeek d) {
        return d.getDisplayName(TextStyle.SHORT, loc());
    }

    static String two(int v) {
        return v < 10 ? "0" + v : String.valueOf(v);
    }

    /** Minutes after local midnight to a clock string. */
    static String clock(int mi) {
        if (mi == Integer.MIN_VALUE) return "--:--";
        mi = ((mi % 1440) + 1440) % 1440;
        int h = mi / 60, m = mi % 60;
        if (h24) return n(two(h) + ":" + two(m));
        boolean pm = h >= 12;
        h = h % 12;
        if (h == 0) h = 12;
        return n(h + ":" + two(m)) + " " + (pm ? L("م", "PM") : L("ص", "AM"));
    }
}
