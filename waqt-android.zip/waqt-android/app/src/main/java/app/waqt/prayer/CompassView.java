package app.waqt.prayer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Rotating dial with a gold Qibla arrow and a fixed phone marker at the top. */
final class CompassView extends View {
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gold = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float heading = 0, bearing = 0;
    private int cFill, cLine, cFg, cMuted, cAcc, cGood, cBad;

    CompassView(Context c) {
        super(c);
    }

    void colors(int fillC, int line, int fgC, int muted, int acc, int good, int bad) {
        cFill = fillC; cLine = line; cFg = fgC; cMuted = muted; cAcc = acc; cGood = good; cBad = bad;
        invalidate();
    }

    void setBearing(float b) { bearing = b; invalidate(); }
    void setHeading(float h) { heading = h; invalidate(); }

    boolean aligned() {
        float d = ((bearing - heading + 540) % 360) - 180;
        return Math.abs(d) < 3;
    }

    float delta() {
        return ((bearing - heading + 540) % 360) - 180;
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - 8;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(cFill);
        cv.drawCircle(cx, cy, r, fill);
        boolean ok = aligned();
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(ok ? 8 : 3);
        ring.setColor(ok ? cGood : cLine);
        cv.drawCircle(cx, cy, r, ring);

        cv.save();
        cv.rotate(-heading, cx, cy);
        tick.setColor(cMuted);
        for (int a = 0; a < 360; a += 10) {
            boolean big = a % 90 == 0;
            tick.setStrokeWidth(big ? 5 : 2);
            cv.save();
            cv.rotate(a, cx, cy);
            cv.drawLine(cx, cy - r + 6, cx, cy - r + (big ? 34 : 20), tick);
            cv.restore();
        }
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setTextSize(r * 0.1f);
        txt.setFakeBoldText(true);
        String[] l = {"N", "E", "S", "W"};
        for (int i = 0; i < 4; i++) {
            cv.save();
            cv.rotate(i * 90, cx, cy);
            txt.setColor(i == 0 ? cBad : cFg);
            cv.drawText(l[i], cx, cy - r + 34 + r * 0.12f, txt);
            cv.restore();
        }
        cv.save();
        cv.rotate(bearing, cx, cy);
        gold.setColor(cAcc);
        gold.setStyle(Paint.Style.FILL);
        Path ar = new Path();
        ar.moveTo(cx, cy - r * 0.78f);
        ar.lineTo(cx + r * 0.09f, cy - r * 0.55f);
        ar.lineTo(cx, cy - r * 0.6f);
        ar.lineTo(cx - r * 0.09f, cy - r * 0.55f);
        ar.close();
        cv.drawPath(ar, gold);
        gold.setStrokeWidth(7);
        gold.setStrokeCap(Paint.Cap.ROUND);
        cv.drawLine(cx, cy - r * 0.58f, cx, cy, gold);
        cv.restore();
        cv.restore();

        fg.setColor(cFg);
        fg.setStyle(Paint.Style.FILL);
        Path tri = new Path();
        tri.moveTo(cx, 2);
        tri.lineTo(cx + 12, 26);
        tri.lineTo(cx - 12, 26);
        tri.close();
        cv.drawPath(tri, fg);
        cv.drawCircle(cx, cy, 9, fg);
    }
}
