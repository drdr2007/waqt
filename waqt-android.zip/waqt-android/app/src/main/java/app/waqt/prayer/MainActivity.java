package app.waqt.prayer;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.drawable.GradientDrawable;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.time.DateTimeException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.chrono.HijrahDate;
import java.time.temporal.ChronoUnit;

public class MainActivity extends Activity implements SensorEventListener {
    private Prefs p;
    private FrameLayout content;
    private LinearLayout bar;
    private final TextView[] tabViews = new TextView[4];
    private int tab = 0, viewOff = 0, calY, calM;
    private boolean convHijri = false;
    private String convResult = "";
    private final Handler h = new Handler(Looper.getMainLooper());
    private TextView cdView;
    private ProgressBar progress;
    private Times.Np curNext, curPrev;
    private boolean dark;
    private int BG, SURF, SURF2, LINE, FG, MUTED, ACC, ACCT, ONACC, GOOD, BAD;

    // compass
    private CompassView compass;
    private TextView qMsg;
    private SensorManager sm;
    private final float[] rm = new float[9], rm2 = new float[9], ori = new float[3];
    private float smooth = Float.NaN;
    private GeomagneticField gf;
    private boolean wasAligned;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (tab == 0 && cdView != null && curNext != null) {
                long now = System.currentTimeMillis();
                if (now >= curNext.ms) {
                    show(0);
                } else {
                    cdView.setText(Times.countdown(curNext.ms - now));
                    updateProgress(now);
                }
            }
            h.postDelayed(this, 1000);
        }
    };

    // ---------- lifecycle ----------

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = new Prefs(this);
        Tx.init(p);
        initColors();
        setTheme(dark ? android.R.style.Theme_DeviceDefault_NoActionBar : android.R.style.Theme_DeviceDefault_Light_NoActionBar);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(SURF);
        if (!dark) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setFitsSystemWindows(true);
        root.setLayoutDirection(Tx.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        bar = new LinearLayout(this);
        bar.setBackground(shape(SURF, LINE, 0));
        String[] names = {Tx.L("الصلوات", "Prayers"), Tx.L("التقويم", "Calendar"), Tx.L("القبلة", "Qibla"), Tx.L("الإعدادات", "Settings")};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            TextView t = tv(names[i], 13, MUTED, false);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(14), 0, dp(14));
            t.setOnClickListener(v -> { viewOff = i0(idx); show(idx); });
            tabViews[i] = t;
            bar.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);

        LocalDate today = LocalDate.now();
        calY = today.getYear();
        calM = today.getMonthValue();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 40);
        }
        Notifier.ensureChannels(this);
        Scheduler.scheduleNext(this);
        WidgetProvider.refresh(this);
        show(0);
    }

    private int i0(int idx) { return idx == 0 ? 0 : viewOff; }

    @Override
    protected void onResume() {
        super.onResume();
        h.removeCallbacks(ticker);
        h.postDelayed(ticker, 1000);
        Scheduler.scheduleNext(this);
        if (tab == 3) show(3);
        if (tab == 2) startSensors();
    }

    @Override
    protected void onPause() {
        h.removeCallbacks(ticker);
        stopSensors();
        stopPreview();
        super.onPause();
    }

    private void initColors() {
        String th = p.s("theme", "auto");
        boolean sysDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        dark = th.equals("dark") || (th.equals("auto") && sysDark);
        ACC = 0xFFE0B43A;
        ONACC = 0xFF1A1405;
        if (dark) {
            BG = 0xFF0C110F; SURF = 0xFF151C19; SURF2 = 0xFF1D2622; LINE = 0xFF28332E; FG = 0xFFEDF0EA; MUTED = 0xFF93A198;
            ACCT = 0xFFE8C25A; GOOD = 0xFF46C48B; BAD = 0xFFEE7B7B;
        } else {
            BG = 0xFFF0F3F1; SURF = 0xFFFFFFFF; SURF2 = 0xFFE6ECE8; LINE = 0xFFD3DCD6; FG = 0xFF14201B; MUTED = 0xFF566860;
            ACCT = 0xFF7D5B00; GOOD = 0xFF17784F; BAD = 0xFFB83A3A;
        }
    }

    // ---------- view helpers ----------

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView tv(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        return t;
    }

    private LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout hbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private GradientDrawable shape(int fill, int stroke, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        if (stroke != 0) g.setStroke(dp(1), stroke);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private LinearLayout card() {
        LinearLayout c = vbox();
        c.setBackground(shape(SURF, LINE, 16));
        return c;
    }

    private LinearLayout.LayoutParams lp(int w, int hh, float weight, int top) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(w, hh, weight);
        l.topMargin = dp(top);
        return l;
    }

    private View spacer(int dpH) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(dpH)));
        return v;
    }

    private TextView button(String label, boolean primary, final Runnable r) {
        TextView t = tv(label, 15, primary ? ONACC : FG, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(11), dp(16), dp(11));
        t.setBackground(shape(primary ? ACC : SURF2, primary ? 0 : LINE, 12));
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private View header(String title) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(6), 0, dp(10));
        TextView t = tv(title, 24, FG, true);
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView city = tv(Times.loc(p).name, 14, MUTED, false);
        city.setOnClickListener(v -> show(3));
        r.addView(city);
        return r;
    }

    private void show(int t) {
        if (tab == 2 && t != 2) stopSensors();
        tab = t;
        content.removeAllViews();
        cdView = null;
        progress = null;
        compass = null;
        ScrollView sv = new ScrollView(this);
        LinearLayout page = vbox();
        page.setPadding(dp(16), dp(8), dp(16), dp(20));
        View v;
        switch (t) {
            case 1: v = calendarView(); break;
            case 2: v = qiblaView(); break;
            case 3: v = settingsView(); break;
            default: v = prayersView(); break;
        }
        page.addView(v);
        sv.addView(page);
        content.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        for (int i = 0; i < 4; i++) {
            boolean on = i == t;
            tabViews[i].setTextColor(on ? ACCT : MUTED);
            tabViews[i].setBackgroundColor(on ? SURF2 : SURF);
        }
        if (t == 2) startSensors();
    }

    // ---------- prayers ----------

    private View prayersView() {
        LinearLayout col = vbox();
        col.addView(header(Tx.L("مواقيت الصلاة", "Prayer times")));
        long now = System.currentTimeMillis();
        Times.Np[] np = Times.nextAndPrev(p, now);
        curNext = np[0];
        curPrev = np[1];
        Times.Day today = Times.day(p, 0);
        Times.Loc loc = Times.loc(p);
        Times.Day vd = viewOff == 0 ? today : Times.day(p, viewOff);

        LinearLayout hero = vbox();
        GradientDrawable hg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF18382F, 0xFF0E2119});
        hg.setCornerRadius(dp(22));
        hero.setBackground(hg);
        hero.setPadding(dp(18), dp(16), dp(18), dp(14));
        LinearLayout top = hbox();
        top.addView(tv(Tx.n(today.date.getDayOfMonth()) + " " + Tx.gMonth(today.date.getMonthValue()), 18, 0xFFF3F6F0, true), new LinearLayout.LayoutParams(0, -2, 1f));
        top.addView(tv(Tx.n(today.hd) + " " + Tx.hm(today.hm), 18, 0xFFF3F6F0, true));
        hero.addView(top);
        if (curNext != null) {
            TextView lbl = tv(Tx.L("الصلاة القادمة", "Next prayer"), 13, 0xFFB4C4BB, false);
            lbl.setGravity(Gravity.CENTER);
            lbl.setPadding(0, dp(14), 0, 0);
            hero.addView(lbl);
            TextView nm = tv(Tx.pr(curNext.k), 36, 0xFFF3F6F0, true);
            nm.setGravity(Gravity.CENTER);
            hero.addView(nm);
            TextView tm = tv(Tx.clock(curNext.day.mins[curNext.k]), 20, ACC, false);
            tm.setGravity(Gravity.CENTER);
            hero.addView(tm);
            cdView = tv(Times.countdown(curNext.ms - now), 20, 0xFFF3F6F0, true);
            cdView.setGravity(Gravity.CENTER);
            cdView.setPadding(0, dp(4), 0, dp(10));
            hero.addView(cdView);
        }
        LinearLayout bot = hbox();
        bot.addView(tv(Tx.weekday(today.date.getDayOfWeek()), 14, 0xFFB4C4BB, false), new LinearLayout.LayoutParams(0, -2, 1f));
        bot.addView(tv(loc.name, 14, 0xFFB4C4BB, false));
        hero.addView(bot);
        col.addView(hero);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000);
        progress.setProgressTintList(ColorStateList.valueOf(ACC));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(SURF2));
        col.addView(progress, lp(-1, dp(10), 0, 12));
        if (curPrev != null && curNext != null) {
            LinearLayout pl = hbox();
            pl.addView(tv(Tx.pr(curPrev.k) + " " + Tx.clock(curPrev.day.mins[curPrev.k]), 13, MUTED, false), new LinearLayout.LayoutParams(0, -2, 1f));
            pl.addView(tv(Tx.pr(curNext.k) + " " + Tx.clock(curNext.day.mins[curNext.k]), 13, MUTED, false));
            col.addView(pl);
        }
        updateProgress(now);

        // day navigation
        LinearLayout nav = hbox();
        nav.setPadding(0, dp(14), 0, dp(8));
        nav.addView(navBtn(Tx.ar ? "›" : "‹", () -> { viewOff--; show(0); }));
        LinearLayout mid = vbox();
        mid.setGravity(Gravity.CENTER);
        TextView d1 = tv(Tx.weekday(vd.date.getDayOfWeek()) + "، " + Tx.n(vd.date.getDayOfMonth()) + " " + Tx.gMonth(vd.date.getMonthValue()), 15, FG, true);
        d1.setGravity(Gravity.CENTER);
        TextView d2 = tv(Tx.n(vd.hd) + " " + Tx.hm(vd.hm) + " " + Tx.n(vd.hy), 12, MUTED, false);
        d2.setGravity(Gravity.CENTER);
        mid.addView(d1);
        mid.addView(d2);
        nav.addView(mid, new LinearLayout.LayoutParams(0, -2, 1f));
        nav.addView(navBtn(Tx.ar ? "‹" : "›", () -> { viewOff++; show(0); }));
        col.addView(nav);
        if (viewOff != 0) {
            TextView back = button(Tx.L("العودة إلى اليوم", "Back to today"), false, () -> { viewOff = 0; show(0); });
            col.addView(back, lp(-2, -2, 0, 0));
        }
        if (vd.ramadan) {
            TextView ram = tv(Tx.L("إمساك ", "Imsak ") + Tx.clock(vd.mins[0] - 10) + "   ·   " + Tx.L("إفطار ", "Iftar ") + Tx.clock(vd.mins[4]), 14, ACCT, true);
            ram.setPadding(0, dp(6), 0, dp(6));
            col.addView(ram);
        }
        for (int k = 0; k < 6; k++) {
            final int kk = k;
            boolean isNext = viewOff == 0 && curNext != null && curNext.day.key.equals(vd.key) && curNext.k == k;
            boolean past = viewOff == 0 && vd.ms[k] != Long.MIN_VALUE && vd.ms[k] < now && !isNext;
            LinearLayout row = hbox();
            row.setPadding(dp(16), dp(14), dp(12), dp(14));
            row.setBackground(isNext ? shape(ACC, 0, 16) : shape(SURF, LINE, 16));
            int fgc = isNext ? ONACC : (past ? MUTED : FG);
            row.addView(tv(Tx.pr(k), k == 1 ? 15 : 17, fgc, false), new LinearLayout.LayoutParams(0, -2, 1f));
            row.addView(tv(Tx.clock(vd.mins[k]), k == 1 ? 15 : 17, fgc, true));
            Switch sw = new Switch(this);
            sw.setChecked(p.alert(k));
            sw.setOnCheckedChangeListener((bv, on) -> { p.put("al" + kk, on); Scheduler.scheduleNext(this); WidgetProvider.refresh(this); });
            row.addView(sw);
            col.addView(row, lp(-1, -2, 0, 8));
        }
        return col;
    }

    private View navBtn(String glyph, Runnable r) {
        TextView t = tv(glyph, 24, FG, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(shape(SURF, LINE, 12));
        t.setOnClickListener(v -> r.run());
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        return t;
    }

    private void updateProgress(long now) {
        if (progress == null || curNext == null || curPrev == null) return;
        long span = curNext.ms - curPrev.ms;
        if (span <= 0) return;
        progress.setProgress((int) Math.max(0, Math.min(1000, (now - curPrev.ms) * 1000 / span)));
    }

    // ---------- calendar ----------

    private EditText etD, etM, etY;
    private String cvD, cvM, cvY;

    private View calendarView() {
        LinearLayout col = vbox();
        col.addView(header(Tx.L("التقويم", "Calendar")));
        LinearLayout nav = hbox();
        nav.addView(navBtn(Tx.ar ? "›" : "‹", () -> { calM--; if (calM < 1) { calM = 12; calY--; } show(1); }));
        LocalDate first = LocalDate.of(calY, calM, 1);
        int dim = first.lengthOfMonth();
        int[] h1 = Times.hijri(first, p.i("hAdj", 0)), h2 = Times.hijri(first.withDayOfMonth(dim), p.i("hAdj", 0));
        String hl = h1[1] == h2[1] ? Tx.hm(h1[1]) + " " + Tx.n(h1[0]) : Tx.hm(h1[1]) + " – " + Tx.hm(h2[1]) + " " + Tx.n(h2[0]);
        LinearLayout mid = vbox();
        TextView a = tv(Tx.gMonth(calM) + " " + Tx.n(calY), 19, FG, true);
        a.setGravity(Gravity.CENTER);
        TextView b2 = tv(hl, 12, MUTED, false);
        b2.setGravity(Gravity.CENTER);
        mid.addView(a);
        mid.addView(b2);
        nav.addView(mid, new LinearLayout.LayoutParams(0, -2, 1f));
        nav.addView(navBtn(Tx.ar ? "‹" : "›", () -> { calM++; if (calM > 12) { calM = 1; calY++; } show(1); }));
        col.addView(nav);

        int ws = p.i("weekStart", Tx.ar ? 6 : 0);
        LinearLayout hd = hbox();
        for (int i = 0; i < 7; i++) {
            int di = (ws + i) % 7;
            TextView t = tv(Tx.weekdayShort(DayOfWeek.of(di == 0 ? 7 : di)), 11, MUTED, false);
            t.setGravity(Gravity.CENTER);
            hd.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        col.addView(hd, lp(-1, -2, 0, 12));
        int lead = ((first.getDayOfWeek().getValue() % 7) - ws + 7) % 7;
        LocalDate today = LocalDate.now(java.time.ZoneId.of(Times.loc(p).tz));
        int cell = 0;
        LinearLayout rowL = null;
        for (int i = 0; i < lead + dim; i++) {
            if (i % 7 == 0) {
                rowL = hbox();
                col.addView(rowL, lp(-1, -2, 0, 4));
            }
            if (i < lead) {
                rowL.addView(new View(this), new LinearLayout.LayoutParams(0, dp(52), 1f));
                continue;
            }
            final LocalDate d = first.withDayOfMonth(i - lead + 1);
            int[] hj = Times.hijri(d, p.i("hAdj", 0));
            LinearLayout c = vbox();
            c.setGravity(Gravity.CENTER);
            boolean isT = d.equals(today);
            c.setBackground(shape(isT ? ACC : SURF2, 0, 10));
            c.addView(tv(Tx.n(d.getDayOfMonth()), 15, isT ? ONACC : FG, true));
            c.addView(tv(Tx.n(hj[2]), 10, isT ? ONACC : MUTED, false));
            c.setOnClickListener(v -> { viewOff = (int) ChronoUnit.DAYS.between(today, d); show(0); });
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, dp(52), 1f);
            l.setMargins(dp(2), 0, dp(2), 0);
            rowL.addView(c, l);
            cell++;
        }
        TextView tip = tv(Tx.L("اضغط على يوم لعرض مواقيته.", "Tap a day to see its prayer times."), 12, MUTED, false);
        tip.setPadding(0, dp(8), 0, dp(14));
        col.addView(tip);

        // converter
        LinearLayout cv = card();
        cv.setPadding(dp(16), dp(14), dp(16), dp(16));
        cv.addView(tv(Tx.L("تحويل التاريخ", "Date converter"), 17, FG, true));
        LinearLayout modes = hbox();
        TextView m1 = button(Tx.L("من الميلادي", "From Gregorian"), !convHijri, () -> { convHijri = false; convResult = ""; cvD = cvM = cvY = null; show(1); });
        TextView m2 = button(Tx.L("من الهجري", "From Hijri"), convHijri, () -> { convHijri = true; convResult = ""; cvD = cvM = cvY = null; show(1); });
        modes.addView(m1, new LinearLayout.LayoutParams(0, -2, 1f));
        modes.addView(m2, new LinearLayout.LayoutParams(0, -2, 1f));
        ((LinearLayout.LayoutParams) m2.getLayoutParams()).setMarginStart(dp(8));
        cv.addView(modes, lp(-1, -2, 0, 10));
        LinearLayout f = hbox();
        etD = field(Tx.L("يوم", "Day"));
        etM = field(Tx.L("شهر", "Month"));
        etY = field(Tx.L("سنة", "Year"));
        int[] hj0 = Times.hijri(today, p.i("hAdj", 0));
        etD.setText(cvD != null ? cvD : String.valueOf(convHijri ? hj0[2] : today.getDayOfMonth()));
        etM.setText(cvM != null ? cvM : String.valueOf(convHijri ? hj0[1] : today.getMonthValue()));
        etY.setText(cvY != null ? cvY : String.valueOf(convHijri ? hj0[0] : today.getYear()));
        f.addView(etD, new LinearLayout.LayoutParams(0, -2, 1f));
        f.addView(etM, new LinearLayout.LayoutParams(0, -2, 1f));
        f.addView(etY, new LinearLayout.LayoutParams(0, -2, 1.4f));
        cv.addView(f, lp(-1, -2, 0, 10));
        TextView res = tv(convResult, 20, ACCT, true);
        res.setGravity(Gravity.CENTER);
        cv.addView(button(Tx.L("تحويل", "Convert"), true, this::convert), lp(-1, -2, 0, 10));
        cv.addView(res, lp(-1, -2, 0, 10));
        TextView note = tv(Tx.L("قد يختلف التحويل بيوم أو يومين عن رؤية الهلال.", "Conversion may differ by a day or two from moon sighting."), 12, MUTED, false);
        note.setGravity(Gravity.CENTER);
        cv.addView(note);
        col.addView(cv);
        return col;
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setTextColor(FG);
        e.setHintTextColor(MUTED);
        e.setGravity(Gravity.CENTER);
        e.setSingleLine(true);
        return e;
    }

    private void convert() {
        cvD = etD.getText().toString().trim();
        cvM = etM.getText().toString().trim();
        cvY = etY.getText().toString().trim();
        try {
            int d = Integer.parseInt(etD.getText().toString().trim());
            int m = Integer.parseInt(etM.getText().toString().trim());
            int y = Integer.parseInt(etY.getText().toString().trim());
            int adj = p.i("hAdj", 0);
            if (!convHijri) {
                LocalDate g = LocalDate.of(y, m, d);
                int[] hj = Times.hijri(g, adj);
                convResult = Tx.n(hj[2]) + " " + Tx.hm(hj[1]) + " " + Tx.n(hj[0]) + Tx.L(" هـ", " AH") + "\n" + Tx.weekday(g.getDayOfWeek());
            } else {
                LocalDate g = LocalDate.from(HijrahDate.of(y, m, d)).minusDays(adj);
                convResult = Tx.n(g.getDayOfMonth()) + " " + Tx.gMonth(g.getMonthValue()) + " " + Tx.n(g.getYear()) + "\n" + Tx.weekday(g.getDayOfWeek());
            }
        } catch (DateTimeException | NumberFormatException e) {
            convResult = Tx.L("تاريخ غير صالح", "Invalid date");
        }
        show(1);
    }

    // ---------- qibla ----------

    private View qiblaView() {
        LinearLayout col = vbox();
        col.addView(header(Tx.L("اتجاه القبلة", "Qibla")));
        Times.Loc loc = Times.loc(p);
        double bearing = PrayerEngine.qiblaBearing(loc.lat, loc.lng);
        long km = Math.round(PrayerEngine.distanceKm(loc.lat, loc.lng));
        TextView big = tv(Tx.n((int) Math.round(bearing)) + "°", 34, FG, true);
        big.setGravity(Gravity.CENTER);
        col.addView(big);
        TextView sub = tv(Tx.L("من الشمال الحقيقي في ", "From true north in ") + loc.name + " · " + Tx.n(String.valueOf(km)) + Tx.L(" كم إلى الكعبة", " km to the Kaaba"), 13, MUTED, false);
        sub.setGravity(Gravity.CENTER);
        col.addView(sub);
        compass = new CompassView(this);
        compass.colors(SURF2, LINE, FG, MUTED, ACC, GOOD, BAD);
        compass.setBearing((float) bearing);
        col.addView(compass, lp(-1, dp(330), 0, 12));
        qMsg = tv("", 15, MUTED, false);
        qMsg.setGravity(Gravity.CENTER);
        col.addView(qMsg, lp(-1, -2, 0, 8));
        TextView tip = tv(Tx.L("امسك الهاتف أفقياً أو عمودياً وحرّكه ببطء. ابتعد عن المعادن والمغناطيس. إذا ضعفت الدقة حرّك الهاتف على شكل ٨.", "Hold the phone flat or upright and move it slowly. Stay away from metal and magnets. If accuracy drops, wave the phone in a figure 8."), 12, MUTED, false);
        tip.setGravity(Gravity.CENTER);
        col.addView(tip, lp(-1, -2, 0, 8));
        gf = new GeomagneticField((float) loc.lat, (float) loc.lng, 0f, System.currentTimeMillis());
        return col;
    }

    private void startSensors() {
        if (compass == null) return;
        sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        Sensor rot = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        if (rot == null) {
            qMsg.setText(Tx.L("هذا الجهاز لا يحتوي على حساس بوصلة.", "This device has no compass sensor."));
            return;
        }
        smooth = Float.NaN;
        sm.registerListener(this, rot, SensorManager.SENSOR_DELAY_UI);
    }

    private void stopSensors() {
        if (sm != null) sm.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        if (compass == null || tab != 2) return;
        SensorManager.getRotationMatrixFromVector(rm, e.values);
        SensorManager.getOrientation(rm, ori);
        if (Math.abs(Math.toDegrees(ori[1])) > 50) {
            SensorManager.remapCoordinateSystem(rm, SensorManager.AXIS_X, SensorManager.AXIS_Z, rm2);
            SensorManager.getOrientation(rm2, ori);
        }
        float az = (float) Math.toDegrees(ori[0]);
        if (gf != null) az += gf.getDeclination();
        az = (az + 720) % 360;
        if (Float.isNaN(smooth)) smooth = az;
        else {
            float d = ((az - smooth + 540) % 360) - 180;
            smooth = (smooth + 0.2f * d + 360) % 360;
        }
        compass.setHeading(smooth);
        boolean ok = compass.aligned();
        if (ok && !wasAligned) {
            try { ((android.os.Vibrator) getSystemService(Context.VIBRATOR_SERVICE)).vibrate(android.os.VibrationEffect.createOneShot(40, 120)); } catch (Exception ignored) { }
        }
        wasAligned = ok;
        if (qMsg != null) {
            qMsg.setTextColor(ok ? GOOD : MUTED);
            float d = compass.delta();
            qMsg.setText(ok ? Tx.L("أنت متجه نحو القبلة", "You are facing the Qibla")
                : Tx.L("أدر الهاتف ", "Turn ") + Tx.n(Math.round(Math.abs(d))) + "° " + (d > 0 ? Tx.L("إلى اليمين", "right") : Tx.L("إلى اليسار", "left")));
        }
    }

    @Override
    public void onAccuracyChanged(Sensor s, int accuracy) {
        if (qMsg != null && accuracy <= SensorManager.SENSOR_STATUS_ACCURACY_LOW && tab == 2) {
            qMsg.setText(Tx.L("الحساس يحتاج معايرة: حرّك الهاتف على شكل ٨.", "Compass needs calibration: wave the phone in a figure 8."));
        }
    }

    // ---------- settings ----------

    private interface Pick { void on(int index); }

    private View settingsView() {
        LinearLayout col = vbox();
        col.addView(header(Tx.L("الإعدادات", "Settings")));

        // system status first, so problems are visible
        LinearLayout sys = card();
        boolean notifOk = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        boolean exactOk = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean batOk = pm.isIgnoringBatteryOptimizations(getPackageName());
        col.addView(head(Tx.L("جاهزية التنبيهات", "Alert readiness")));
        Scheduler.Ev ev = Scheduler.next(p, System.currentTimeMillis());
        String nextTxt = ev == null ? Tx.L("لا يوجد تنبيه مجدول", "Nothing scheduled") : Tx.L("التنبيه القادم: ", "Next alert: ") + evName(ev) + " · " + java.time.format.DateTimeFormatter.ofPattern(Tx.h24 ? "HH:mm" : "h:mm a", Tx.loc()).format(java.time.Instant.ofEpochMilli(ev.at).atZone(java.time.ZoneId.of(Times.loc(p).tz)));
        add(sys, row(Tx.L("الجدولة", "Scheduling"), nextTxt, null));
        add(sys, row(Tx.L("إذن الإشعارات", "Notification permission"), notifOk ? Tx.L("مسموح", "Allowed") : Tx.L("غير مسموح. بدونه لن تظهر التنبيهات.", "Not allowed. Alerts will not appear."),
            notifOk ? null : button(Tx.L("السماح", "Allow"), true, () -> { if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 40); })));
        add(sys, row(Tx.L("المنبّهات الدقيقة", "Exact alarms"), exactOk ? Tx.L("مسموح", "Allowed") : Tx.L("غير مسموح. قد يتأخر التنبيه.", "Not allowed. Alerts may be late."),
            exactOk ? null : button(Tx.L("السماح", "Allow"), true, () -> startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()))))));
        add(sys, row(Tx.L("توفير البطارية", "Battery optimization"), batOk ? Tx.L("مستثنى. ممتاز.", "Exempt. Good.") : Tx.L("استثنِ التطبيق كي لا يوقفه النظام", "Exempt the app so the system does not stop it"),
            batOk ? null : button(Tx.L("استثناء", "Exempt"), true, () -> startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()))))));
        LinearLayout tests = hbox();
        tests.setPadding(dp(16), dp(10), dp(16), dp(14));
        tests.addView(button(Tx.L("تجربة الأذان", "Test adhan"), false, () -> AdhanService.start(this, Scheduler.TYPE_PRAYER, 3)), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView t2 = button(Tx.L("تجربة المنبّه", "Test alarm"), false, () -> { AdhanService.start(this, Scheduler.TYPE_ALARM, 0); startActivity(new Intent(this, AlarmActivity.class)); });
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, -2, 1f);
        l2.setMarginStart(dp(8));
        tests.addView(t2, l2);
        sys.addView(tests);
        col.addView(sys);

        // prayer times
        col.addView(head(Tx.L("إعدادات أوقات الصلوات", "Prayer time settings")));
        LinearLayout c1 = card();
        String[] mnames = Tx.ar ? PrayerEngine.NAME_AR : PrayerEngine.NAME_EN;
        add(c1, spinnerRow(Tx.L("طريقة الحساب", "Calculation method"), mnames, PrayerEngine.methodIndex(p.s("method", "makkah")), i -> { p.put("method", PrayerEngine.KEYS[i]); changed(); }));
        add(c1, spinnerRow(Tx.L("وقت العصر", "Asr"), new String[]{Tx.L("الجمهور", "Standard (Shafi, Maliki, Hanbali)"), Tx.L("الحنفي", "Hanafi")}, p.i("asr", 1) == 2 ? 1 : 0, i -> { p.put("asr", i == 1 ? 2 : 1); changed(); }));
        String[] hlKeys = {"angle", "mid", "seventh", "none"};
        add(c1, spinnerRow(Tx.L("خطوط العرض العالية", "Higher latitudes"), new String[]{Tx.L("بحسب الزاوية", "Angle based"), Tx.L("منتصف الليل", "Middle of night"), Tx.L("سُبع الليل", "One seventh"), Tx.L("بدون", "None")}, indexOf(hlKeys, p.s("hl", "angle")), i -> { p.put("hl", hlKeys[i]); changed(); }));
        for (int k = 0; k < 6; k++) add(c1, stepRow(Tx.L("تعديل ", "Offset ") + Tx.pr(k), "adj" + k, -30, 30, 1, Tx.L(" د", " min"), 0));
        col.addView(c1);

        // hijri
        col.addView(head(Tx.L("إعدادات التاريخ الهجري", "Hijri settings")));
        LinearLayout c2 = card();
        add(c2, stepRow(Tx.L("تعديل التاريخ الهجري", "Hijri date adjustment"), "hAdj", -3, 3, 1, Tx.L(" يوم", " day"), 0));
        Times.Day td = Times.day(p, 0);
        add(c2, row(Tx.L("اليوم", "Today"), Tx.n(td.hd) + " " + Tx.hm(td.hm) + " " + Tx.n(td.hy) + " (" + Tx.L("أم القرى", "Umm al-Qura") + ")", null));
        col.addView(c2);

        // location
        col.addView(head(Tx.L("إعدادات الموقع", "Location settings")));
        LinearLayout c3 = card();
        String[] cn = new String[Cities.D.length];
        for (int i = 0; i < cn.length; i++) cn[i] = Tx.ar ? Cities.D[i][1] : Cities.D[i][2];
        add(c3, spinnerRow(Tx.L("المدينة", "City"), cn, Cities.indexOf(p.s("cityId", "riyadh")), i -> { p.put("cityId", Cities.D[i][0]); p.put("gps", false); changed(); }));
        Times.Loc loc = Times.loc(p);
        add(c3, row(Tx.L("الموقع الحالي", "Active location"), loc.name + (p.b("gps", false) ? " (GPS)" : "") + " · " + Tx.n(String.format(java.util.Locale.ENGLISH, "%.3f, %.3f", loc.lat, loc.lng)), button(Tx.L("استخدم GPS", "Use GPS"), false, this::useGps)));
        col.addView(c3);

        // display
        col.addView(head(Tx.L("خصائص العرض", "Display options")));
        LinearLayout c4 = card();
        add(c4, spinnerRow(Tx.L("اللغة", "Language"), new String[]{"العربية", "English"}, Tx.ar ? 0 : 1, i -> { p.put("lang", i == 0 ? "ar" : "en"); recreate(); }));
        String[] themes = {"auto", "light", "dark"};
        add(c4, spinnerRow(Tx.L("المظهر", "Theme"), new String[]{Tx.L("تلقائي", "Automatic"), Tx.L("فاتح", "Light"), Tx.L("داكن", "Dark")}, indexOf(themes, p.s("theme", "auto")), i -> { p.put("theme", themes[i]); recreate(); }));
        add(c4, switchRow(Tx.L("نظام ٢٤ ساعة", "24-hour time"), null, p.b("h24", false), on -> { p.put("h24", on); Tx.init(p); WidgetProvider.refresh(this); show(3); }));
        if (Tx.ar) add(c4, switchRow(Tx.L("الأرقام الهندية (٠١٢)", "Arabic-Indic digits"), null, p.b("digits", true), on -> { p.put("digits", on); Tx.init(p); WidgetProvider.refresh(this); show(3); }));
        col.addView(c4);

        // notifications
        col.addView(head(Tx.L("إعدادات التنبيهات", "Notification settings")));
        LinearLayout c5 = card();
        for (int k = 0; k < 6; k++) {
            final int kk = k;
            add(c5, switchRow(Tx.L("تنبيه ", "Alert ") + Tx.pr(k), null, p.alert(k), on -> { p.put("al" + kk, on); Scheduler.scheduleNext(this); WidgetProvider.refresh(this); }));
        }
        add(c5, switchRow(Tx.L("تذكير قبل الصلاة", "Remind before prayer"), null, p.b("pre", false), on -> { p.put("pre", on); Scheduler.scheduleNext(this); show(3); }));
        if (p.b("pre", false)) add(c5, stepRow(Tx.L("قبل الصلاة بـ", "Before prayer by"), "preMin", 1, 60, 1, Tx.L(" د", " min"), 10));
        add(c5, switchRow(Tx.L("الاهتزاز", "Vibration"), null, p.b("vib", true), on -> p.put("vib", on)));
        add(c5, volumeRow());
        add(c5, soundRow("adhan", Tx.L("صوت الأذان", "Adhan sound")));
        add(c5, soundRow("fajr", Tx.L("صوت أذان الفجر", "Fajr adhan sound")));
        col.addView(c5);

        // alarm
        col.addView(head(Tx.L("إنذار الفجر والسحور", "Fajr and Sahoor alarm")));
        LinearLayout c6 = card();
        add(c6, switchRow(Tx.L("تفعيل المنبّه", "Enable alarm"), Tx.L("إذا ضُبط على ٠ دقيقة فإنه يحل محل أذان الفجر", "At 0 minutes it replaces the Fajr adhan"), p.b("alOn", false), on -> { p.put("alOn", on); Scheduler.scheduleNext(this); }));
        String[] types = {"fajr", "sahoor"};
        add(c6, spinnerRow(Tx.L("النوع", "Type"), new String[]{Tx.L("إنذار الفجر", "Fajr alarm"), Tx.L("إنذار السحور", "Sahoor alarm")}, indexOf(types, p.s("alType", "fajr")), i -> p.put("alType", types[i])));
        add(c6, stepRow(Tx.L("قبل أذان الفجر بـ", "Before Fajr by"), "alBefore", 0, 180, 5, Tx.L(" د", " min"), 0));
        add(c6, stepRow(Tx.L("مدة الغفوة", "Snooze length"), "alSnooze", 1, 30, 1, Tx.L(" د", " min"), 5));
        add(c6, switchRow(Tx.L("في رمضان فقط", "Ramadan only"), null, p.b("alRam", false), on -> { p.put("alRam", on); Scheduler.scheduleNext(this); }));
        add(c6, daysRow());
        add(c6, soundRow("alarm", Tx.L("نغمة المنبّه", "Alarm tone")));
        col.addView(c6);

        // silent
        col.addView(head(Tx.L("إعدادات الوضع الصامت", "Silent settings")));
        LinearLayout c7 = card();
        add(c7, switchRow(Tx.L("احترام وضع الهاتف الصامت", "Respect phone silent mode"), Tx.L("إذا كان الهاتف صامتاً أو على الاهتزاز يظهر إشعار بدون أذان", "When the phone is silent or on vibrate, show a notification without adhan"), p.b("rsp", true), on -> p.put("rsp", on)));
        for (int k = 0; k < 6; k++) {
            final int kk = k;
            add(c7, switchRow(Tx.L("إشعار بدون صوت: ", "Silent: ") + Tx.pr(k), null, p.silent(k), on -> p.put("si" + kk, on)));
        }
        col.addView(c7);

        // backup
        col.addView(head(Tx.L("النسخ الاحتياطية", "Backup and restore")));
        LinearLayout c8 = card();
        LinearLayout bk = hbox();
        bk.setPadding(dp(16), dp(12), dp(16), dp(14));
        bk.addView(button(Tx.L("حفظ كملف", "Save to file"), true, () -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE, "waqt-backup.json");
            startActivityForResult(i, 20);
        }), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView imp = button(Tx.L("استعادة من ملف", "Restore from file"), false, () -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
            startActivityForResult(i, 21);
        });
        LinearLayout.LayoutParams l3 = new LinearLayout.LayoutParams(0, -2, 1f);
        l3.setMarginStart(dp(8));
        bk.addView(imp, l3);
        c8.addView(bk);
        col.addView(c8);

        TextView about = tv(Tx.L("الحساب بمعادلات فلكية قياسية وقد تختلف دقيقة عن التقاويم الرسمية. استخدم تعديل الدقائق للمطابقة.", "Times use standard astronomical formulas and may differ by a minute from official timetables. Use the minute offsets to match yours."), 12, MUTED, false);
        about.setPadding(0, dp(14), 0, 0);
        col.addView(about);
        return col;
    }

    private String evName(Scheduler.Ev e) {
        if (e.type == Scheduler.TYPE_ALARM) return Tx.L("المنبّه", "Alarm");
        if (e.type == Scheduler.TYPE_PRE) return Tx.L("تذكير ", "Reminder ") + Tx.pr(e.idx);
        return Tx.pr(e.idx);
    }

    private void changed() {
        Scheduler.scheduleNext(this);
        WidgetProvider.refresh(this);
        show(3);
    }

    private int indexOf(String[] a, String v) {
        for (int i = 0; i < a.length; i++) if (a[i].equals(v)) return i;
        return 0;
    }

    private View head(String s) {
        TextView t = tv(s, 13, ACCT, true);
        t.setPadding(dp(4), dp(18), dp(4), dp(6));
        return t;
    }

    private void add(LinearLayout card, View row) {
        if (card.getChildCount() > 0) {
            View d = new View(this);
            d.setBackgroundColor(LINE);
            card.addView(d, new LinearLayout.LayoutParams(-1, 1));
        }
        card.addView(row);
    }

    private LinearLayout row(String title, String sub, View ctl) {
        LinearLayout r = hbox();
        r.setPadding(dp(16), dp(12), dp(16), dp(12));
        LinearLayout t = vbox();
        t.addView(tv(title, 16, FG, false));
        if (sub != null) t.addView(tv(sub, 13, MUTED, false));
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (ctl != null) r.addView(ctl);
        return r;
    }

    private interface OnBool { void on(boolean v); }

    private View switchRow(String title, String sub, boolean checked, OnBool cb) {
        Switch s = new Switch(this);
        s.setChecked(checked);
        s.setOnCheckedChangeListener((v, on) -> cb.on(on));
        return row(title, sub, s);
    }

    private View spinnerRow(String title, String[] items, int sel, Pick cb) {
        Spinner sp = new Spinner(this);
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items));
        sp.setSelection(sel, false);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> a, View v, int pos, long id) {
                if (pos != sel) cb.on(pos);
            }

            @Override
            public void onNothingSelected(AdapterView<?> a) { }
        });
        LinearLayout r = row(title, null, null);
        sp.setLayoutParams(new LinearLayout.LayoutParams(dp(170), -2));
        r.addView(sp);
        return r;
    }

    private View stepRow(String title, String key, int min, int max, int st, String unit, int def) {
        final TextView val = tv(label(p.i(key, def), unit), 15, FG, true);
        val.setGravity(Gravity.CENTER);
        val.setMinWidth(dp(64));
        LinearLayout c = hbox();
        TextView minus = button("−", false, () -> {
            int v = Math.max(min, p.i(key, def) - st);
            p.put(key, v);
            val.setText(label(v, unit));
            Scheduler.scheduleNext(this);
            WidgetProvider.refresh(this);
        });
        TextView plus = button("+", false, () -> {
            int v = Math.min(max, p.i(key, def) + st);
            p.put(key, v);
            val.setText(label(v, unit));
            Scheduler.scheduleNext(this);
            WidgetProvider.refresh(this);
        });
        minus.setPadding(dp(14), dp(6), dp(14), dp(6));
        plus.setPadding(dp(14), dp(6), dp(14), dp(6));
        c.addView(minus);
        c.addView(val);
        c.addView(plus);
        return row(title, null, c);
    }

    private String label(int v, String unit) {
        return Tx.n((v > 0 && unit.length() > 0 && unit.contains("min") || v > 0 && unit.contains("د") || v > 0 && unit.contains("day") || v > 0 && unit.contains("يوم") ? "+" : "") + v) + unit;
    }

    private View volumeRow() {
        SeekBar sb = new SeekBar(this);
        sb.setMax(100);
        sb.setProgress(p.i("vol", 80));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) { if (user) p.put("vol", Math.max(5, v)); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        LinearLayout r = row(Tx.L("مستوى صوت الأذان", "Adhan volume"), null, null);
        sb.setLayoutParams(new LinearLayout.LayoutParams(dp(170), -2));
        r.addView(sb);
        return r;
    }

    private View daysRow() {
        LinearLayout r = vbox();
        r.setPadding(dp(16), dp(12), dp(16), dp(12));
        r.addView(tv(Tx.L("الأيام", "Days"), 16, FG, false));
        LinearLayout days = hbox();
        for (int i = 0; i < 7; i++) {
            final int bit = i;
            TextView t = tv(Tx.weekdayShort(DayOfWeek.of(i == 0 ? 7 : i)), 12, FG, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(10), 0, dp(10));
            paintDay(t, bit);
            t.setOnClickListener(v -> {
                int m = p.i("alDays", 127) ^ (1 << bit);
                p.put("alDays", m);
                paintDay(t, bit);
                Scheduler.scheduleNext(this);
            });
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, -2, 1f);
            l.setMargins(dp(2), dp(8), dp(2), 0);
            days.addView(t, l);
        }
        r.addView(days);
        return r;
    }

    private void paintDay(TextView t, int bit) {
        boolean on = (p.i("alDays", 127) & (1 << bit)) != 0;
        t.setBackground(shape(on ? ACC : SURF2, 0, 10));
        t.setTextColor(on ? ONACC : MUTED);
    }

    // ---------- sounds ----------

    private MediaPlayer preview;

    private void stopPreview() {
        if (preview != null) {
            try { preview.stop(); } catch (Exception ignored) { }
            try { preview.release(); } catch (Exception ignored) { }
            preview = null;
        }
    }

    private View soundRow(String slot, String title) {
        String uri = p.s("snd_" + slot, "");
        String name = uri.isEmpty() ? Tx.L("النغمة المدمجة", "Built-in chime") : p.s("sn_" + slot, Tx.L("ملف مخصص", "Custom file"));
        LinearLayout ctl = hbox();
        TextView play = button(Tx.L("استماع", "Play"), false, () -> {
            if (preview != null) { stopPreview(); return; }
            preview = Sound.open(this, p, slot, false, false);
            if (preview != null) { preview.setOnCompletionListener(m -> stopPreview()); preview.start(); }
        });
        TextView pick = button(Tx.L("اختيار", "Choose"), false, () -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("audio/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, slot.equals("adhan") ? 10 : slot.equals("fajr") ? 11 : 12);
        });
        play.setPadding(dp(10), dp(8), dp(10), dp(8));
        pick.setPadding(dp(10), dp(8), dp(10), dp(8));
        ctl.addView(play);
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(-2, -2);
        l.setMarginStart(dp(6));
        ctl.addView(pick, l);
        if (!uri.isEmpty()) {
            TextView reset = button("✕", false, () -> { p.remove("snd_" + slot); p.remove("sn_" + slot); show(3); });
            reset.setPadding(dp(10), dp(8), dp(10), dp(8));
            ctl.addView(reset, l);
        }
        return row(title, name, ctl);
    }

    // ---------- results and permissions ----------

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try {
            if (req >= 10 && req <= 12) {
                String slot = req == 10 ? "adhan" : req == 11 ? "fajr" : "alarm";
                try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
                p.put("snd_" + slot, u.toString());
                p.put("sn_" + slot, displayName(u));
                show(3);
            } else if (req == 20) {
                try (OutputStream os = getContentResolver().openOutputStream(u)) {
                    os.write(p.exportJson().getBytes(StandardCharsets.UTF_8));
                }
                Toast.makeText(this, Tx.L("تم حفظ النسخة الاحتياطية.", "Backup saved."), Toast.LENGTH_SHORT).show();
            } else if (req == 21) {
                try (InputStream is = getContentResolver().openInputStream(u)) {
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
                    boolean ok = p.importJson(bo.toString("UTF-8"));
                    Toast.makeText(this, ok ? Tx.L("تمت الاستعادة.", "Restored.") : Tx.L("الملف غير صالح.", "Invalid backup file."), Toast.LENGTH_SHORT).show();
                    if (ok) recreate();
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, Tx.L("تعذّر فتح الملف.", "Could not open the file."), Toast.LENGTH_SHORT).show();
        }
    }

    private String displayName(Uri u) {
        try (android.database.Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) { }
        return Tx.L("ملف مخصص", "Custom file");
    }

    private void useGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, 30);
            return;
        }
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            Location best = null;
            for (String prov : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(prov);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
            if (best != null) {
                applyLocation(best);
            } else if (Build.VERSION.SDK_INT >= 30 && !lm.getProviders(true).isEmpty()) {
                Toast.makeText(this, Tx.L("جارٍ تحديد الموقع…", "Finding your location…"), Toast.LENGTH_SHORT).show();
                lm.getCurrentLocation(lm.getProviders(true).get(0), null, getMainExecutor(), l -> {
                    if (l != null) applyLocation(l);
                    else Toast.makeText(this, Tx.L("تعذّر تحديد الموقع.", "Could not get a location."), Toast.LENGTH_LONG).show();
                });
            } else {
                Toast.makeText(this, Tx.L("فعّل خدمة الموقع في الهاتف ثم أعد المحاولة.", "Turn on location in the phone and try again."), Toast.LENGTH_LONG).show();
            }
        } catch (SecurityException e) {
            Toast.makeText(this, Tx.L("إذن الموقع مرفوض.", "Location permission denied."), Toast.LENGTH_LONG).show();
        }
    }

    private void applyLocation(Location l) {
        p.put("gps", true);
        p.put("lat", String.valueOf(l.getLatitude()));
        p.put("lng", String.valueOf(l.getLongitude()));
        p.put("locName", Tx.L("موقعي", "My location"));
        changed();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] grants) {
        super.onRequestPermissionsResult(req, perms, grants);
        if (req == 30 && grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) useGps();
        else if (req == 40) { Notifier.ensureChannels(this); if (tab == 3) show(3); }
    }
}
