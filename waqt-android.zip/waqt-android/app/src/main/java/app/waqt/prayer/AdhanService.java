package app.waqt.prayer;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

/** Foreground service that plays the adhan or the Fajr alarm while the app is closed. */
public class AdhanService extends Service {
    static final String ACT_STOP = "app.waqt.prayer.STOP", ACT_SNOOZE = "app.waqt.prayer.SNOOZE";
    private MediaPlayer mp;
    private PowerManager.WakeLock wl;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable giveUp = this::shutdown;

    static void start(Context c, int type, int idx) {
        Intent i = new Intent(c, AdhanService.class).putExtra("type", type).putExtra("idx", idx);
        c.startForegroundService(i);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? null : intent.getAction();
        if (ACT_STOP.equals(a)) {
            shutdown();
            return START_NOT_STICKY;
        }
        if (ACT_SNOOZE.equals(a)) {
            Scheduler.scheduleSnooze(this);
            shutdown();
            return START_NOT_STICKY;
        }
        int type = intent == null ? Scheduler.TYPE_PRAYER : intent.getIntExtra("type", Scheduler.TYPE_PRAYER);
        int idx = intent == null ? 0 : intent.getIntExtra("idx", 0);
        Prefs p = new Prefs(this);
        Tx.init(p);
        Notifier.ensureChannels(this);
        Notification n = Notifier.build(this, type, idx, true);
        if (Build.VERSION.SDK_INT >= 29) startForeground(Notifier.ID_MAIN, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(Notifier.ID_MAIN, n);

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "waqt:adhan");
        wl.acquire(6 * 60 * 1000L);

        boolean alarm = type == Scheduler.TYPE_ALARM;
        releasePlayer();
        mp = Sound.open(this, p, Sound.slotFor(p, type, idx), alarm, alarm);
        if (mp != null) {
            mp.setOnCompletionListener(m -> shutdown());
            mp.start();
        }
        if (p.b("vib", true)) vibrate(alarm);
        h.removeCallbacks(giveUp);
        h.postDelayed(giveUp, alarm ? 5 * 60 * 1000L : 6 * 60 * 1000L);
        return START_NOT_STICKY;
    }

    private void vibrate(boolean alarm) {
        try {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            long[] pattern = alarm ? new long[]{0, 600, 400, 600, 400, 600} : new long[]{0, 400, 200, 400};
            v.vibrate(VibrationEffect.createWaveform(pattern, -1));
        } catch (Exception ignored) {
        }
    }

    private void releasePlayer() {
        if (mp != null) {
            try { mp.stop(); } catch (Exception ignored) { }
            try { mp.release(); } catch (Exception ignored) { }
            mp = null;
        }
    }

    private void shutdown() {
        h.removeCallbacks(giveUp);
        releasePlayer();
        if (wl != null && wl.isHeld()) wl.release();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
        sendBroadcast(new Intent("app.waqt.prayer.ALARM_ENDED").setPackage(getPackageName()));
    }

    @Override
    public void onDestroy() {
        releasePlayer();
        if (wl != null && wl.isHeld()) wl.release();
        super.onDestroy();
    }
}
