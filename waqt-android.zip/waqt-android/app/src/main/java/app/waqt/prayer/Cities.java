package app.waqt.prayer;

/** Built-in city list: id, Arabic name, English name, latitude, longitude, time zone. */
final class Cities {
    static final String[][] D = {
        {"makkah", "مكة المكرمة", "Makkah", "21.4225", "39.8262", "Asia/Riyadh"},
        {"madinah", "المدينة المنورة", "Madinah", "24.4672", "39.6024", "Asia/Riyadh"},
        {"riyadh", "الرياض", "Riyadh", "24.7136", "46.6753", "Asia/Riyadh"},
        {"jeddah", "جدة", "Jeddah", "21.5433", "39.1728", "Asia/Riyadh"},
        {"dammam", "الدمام", "Dammam", "26.4207", "50.0888", "Asia/Riyadh"},
        {"abha", "أبها", "Abha", "18.2164", "42.5053", "Asia/Riyadh"},
        {"cairo", "القاهرة", "Cairo", "30.0444", "31.2357", "Africa/Cairo"},
        {"alex", "الإسكندرية", "Alexandria", "31.2001", "29.9187", "Africa/Cairo"},
        {"dubai", "دبي", "Dubai", "25.2048", "55.2708", "Asia/Dubai"},
        {"abudhabi", "أبوظبي", "Abu Dhabi", "24.4539", "54.3773", "Asia/Dubai"},
        {"doha", "الدوحة", "Doha", "25.2854", "51.531", "Asia/Qatar"},
        {"kuwait", "الكويت", "Kuwait City", "29.3759", "47.9774", "Asia/Kuwait"},
        {"manama", "المنامة", "Manama", "26.2285", "50.586", "Asia/Bahrain"},
        {"muscat", "مسقط", "Muscat", "23.588", "58.3829", "Asia/Muscat"},
        {"sanaa", "صنعاء", "Sanaa", "15.3694", "44.191", "Asia/Aden"},
        {"amman", "عمّان", "Amman", "31.9454", "35.9284", "Asia/Amman"},
        {"jerusalem", "القدس", "Jerusalem", "31.7683", "35.2137", "Asia/Jerusalem"},
        {"gaza", "غزة", "Gaza", "31.5", "34.4667", "Asia/Gaza"},
        {"beirut", "بيروت", "Beirut", "33.8938", "35.5018", "Asia/Beirut"},
        {"damascus", "دمشق", "Damascus", "33.5138", "36.2765", "Asia/Damascus"},
        {"baghdad", "بغداد", "Baghdad", "33.3152", "44.3661", "Asia/Baghdad"},
        {"istanbul", "إسطنبول", "Istanbul", "41.0082", "28.9784", "Europe/Istanbul"},
        {"casablanca", "الدار البيضاء", "Casablanca", "33.5731", "-7.5898", "Africa/Casablanca"},
        {"rabat", "الرباط", "Rabat", "34.0209", "-6.8416", "Africa/Casablanca"},
        {"algiers", "الجزائر", "Algiers", "36.7538", "3.0588", "Africa/Algiers"},
        {"tunis", "تونس", "Tunis", "36.8065", "10.1815", "Africa/Tunis"},
        {"tripoli", "طرابلس", "Tripoli", "32.8872", "13.1913", "Africa/Tripoli"},
        {"khartoum", "الخرطوم", "Khartoum", "15.5007", "32.5599", "Africa/Khartoum"},
        {"karachi", "كراتشي", "Karachi", "24.8607", "67.0011", "Asia/Karachi"},
        {"lahore", "لاهور", "Lahore", "31.5497", "74.3436", "Asia/Karachi"},
        {"dhaka", "دكا", "Dhaka", "23.8103", "90.4125", "Asia/Dhaka"},
        {"jakarta", "جاكرتا", "Jakarta", "-6.2088", "106.8456", "Asia/Jakarta"},
        {"kl", "كوالالمبور", "Kuala Lumpur", "3.139", "101.6869", "Asia/Kuala_Lumpur"},
        {"london", "لندن", "London", "51.5072", "-0.1276", "Europe/London"},
        {"paris", "باريس", "Paris", "48.8566", "2.3522", "Europe/Paris"},
        {"berlin", "برلين", "Berlin", "52.52", "13.405", "Europe/Berlin"},
        {"newyork", "نيويورك", "New York", "40.7128", "-74.006", "America/New_York"},
        {"toronto", "تورنتو", "Toronto", "43.6532", "-79.3832", "America/Toronto"},
        {"la", "لوس أنجلوس", "Los Angeles", "34.0522", "-118.2437", "America/Los_Angeles"},
        {"sydney", "سيدني", "Sydney", "-33.8688", "151.2093", "Australia/Sydney"}
    };

    static String[] find(String id) {
        for (String[] c : D) if (c[0].equals(id)) return c;
        return D[2];
    }

    static int indexOf(String id) {
        for (int i = 0; i < D.length; i++) if (D[i][0].equals(id)) return i;
        return 2;
    }
}
