package app.waqt.prayer;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.widget.RemoteViews;

/** Home screen widget with the next prayer and a live countdown. */
public class WidgetProvider extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager mgr, int[] ids) {
        update(c, mgr, ids);
    }

    static void refresh(Context c) {
        try {
            AppWidgetManager mgr = AppWidgetManager.getInstance(c);
            int[] ids = mgr.getAppWidgetIds(new ComponentName(c, WidgetProvider.class));
            if (ids != null && ids.length > 0) update(c, mgr, ids);
        } catch (Exception ignored) {
        }
    }

    private static void update(Context c, AppWidgetManager mgr, int[] ids) {
        Prefs p = new Prefs(c);
        Tx.init(p);
        long now = System.currentTimeMillis();
        Times.Np[] np = Times.nextAndPrev(p, now);
        Times.Np next = np[0];
        for (int id : ids) {
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget);
            if (next != null) {
                rv.setTextViewText(R.id.w_date, Tx.n(next.day.date.getDayOfMonth()) + " " + Tx.gMonth(next.day.date.getMonthValue()) + " · " + Tx.n(next.day.hd) + " " + Tx.hm(next.day.hm));
                rv.setTextViewText(R.id.w_name, Tx.pr(next.k));
                rv.setTextViewText(R.id.w_time, Tx.clock(next.day.mins[next.k]));
                rv.setChronometerCountDown(R.id.w_cd, true);
                rv.setChronometer(R.id.w_cd, SystemClock.elapsedRealtime() + (next.ms - now), null, true);
            }
            PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
            rv.setOnClickPendingIntent(R.id.w_root, open);
            mgr.updateAppWidget(id, rv);
        }
    }
}
