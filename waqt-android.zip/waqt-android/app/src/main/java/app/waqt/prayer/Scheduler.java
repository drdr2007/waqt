package app.waqt.prayer;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Keeps exactly one system alarm set for the next event. Each fired alarm sets the following one. */
final class Scheduler {
    static final int TYPE_PRAYER = 0, TYPE_PRE = 1, TYPE_ALARM = 2, TYPE_REFRESH = 3;
    private static final int RC_NEXT = 1001, RC_SNOOZE = 1002;

    static final class Ev {
        long at;
        int type, idx;
    }

    static Ev next(Prefs p, long now) {
        Ev best = null;
        boolean alarmOn = p.b("alOn", false);
        int before = p.i("alBefore", 0);
        boolean preOn = p.b("pre", false);
        int preMin = p.i("preMin", 10);
        for (int off = -1; off <= 2; off++) {
            Times.Day d = Times.day(p, off);
            boolean alarmToday = false;
            if (alarmOn && d.ms[0] != Long.MIN_VALUE) {
                int dow = d.date.getDayOfWeek().getValue() % 7; // Sunday = 0
                boolean dayOk = (p.i("alDays", 127) & (1 << dow)) != 0;
                boolean ramOk = !p.b("alRam", false) || d.ramadan;
                if (dayOk && ramOk) {
                    alarmToday = true;
                    best = pick(best, d.ms[0] - before * 60000L, TYPE_ALARM, 0, now);
                }
            }
            for (int k = 0; k < 6; k++) {
                if (d.ms[k] == Long.MIN_VALUE) continue;
                if (k == 1 && !p.alert(1)) continue;
                if (k == 0 && alarmToday && before == 0) continue; // the alarm replaces the Fajr adhan
                int type = p.alert(k) ? TYPE_PRAYER : TYPE_REFRESH;
                if (k == 1 && type == TYPE_REFRESH) continue;
                best = pick(best, d.ms[k], type, k, now);
                if (preOn && k != 1 && p.alert(k)) best = pick(best, d.ms[k] - preMin * 60000L, TYPE_PRE, k, now);
            }
        }
        return best;
    }

    private static Ev pick(Ev best, long at, int type, int idx, long now) {
        if (at <= now + 500) return best;
        if (best != null && best.at <= at) return best;
        Ev e = new Ev();
        e.at = at;
        e.type = type;
        e.idx = idx;
        return e;
    }

    static void scheduleNext(Context c) {
        Prefs p = new Prefs(c);
        Tx.init(p);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent old = pi(c, RC_NEXT, 0, 0, false, PendingIntent.FLAG_NO_CREATE);
        if (old != null) am.cancel(old);
        Ev e = next(p, System.currentTimeMillis());
        if (e == null) return;
        set(c, am, e.at, pi(c, RC_NEXT, e.type, e.idx, false, PendingIntent.FLAG_UPDATE_CURRENT));
    }

    static void scheduleSnooze(Context c) {
        Prefs p = new Prefs(c);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        long at = System.currentTimeMillis() + Math.max(1, p.i("alSnooze", 5)) * 60000L;
        set(c, am, at, pi(c, RC_SNOOZE, TYPE_ALARM, 0, true, PendingIntent.FLAG_UPDATE_CURRENT));
    }

    private static void set(Context c, AlarmManager am, long at, PendingIntent pi) {
        boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        if (exact) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } else {
            Intent open = new Intent(c, MainActivity.class);
            PendingIntent show = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_IMMUTABLE);
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), pi);
        }
    }

    private static PendingIntent pi(Context c, int rc, int type, int idx, boolean snooze, int flag) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.setAction("app.waqt.prayer.FIRE." + rc);
        i.putExtra("type", type);
        i.putExtra("idx", idx);
        i.putExtra("snooze", snooze);
        return PendingIntent.getBroadcast(c, rc, i, flag | PendingIntent.FLAG_IMMUTABLE);
    }
}
