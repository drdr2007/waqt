package app.waqt.prayer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;

/** Runs when a scheduled alarm fires: shows the notification or starts the sound, then sets the next alarm. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        int type = intent.getIntExtra("type", Scheduler.TYPE_REFRESH);
        int idx = intent.getIntExtra("idx", 0);
        Prefs p = new Prefs(c);
        Tx.init(p);
        try {
            if (type == Scheduler.TYPE_PRAYER) {
                AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
                boolean ringerQuiet = p.b("rsp", true) && am.getRingerMode() != AudioManager.RINGER_MODE_NORMAL;
                if (p.silent(idx) || ringerQuiet) Notifier.post(c, type, idx);
                else AdhanService.start(c, type, idx);
            } else if (type == Scheduler.TYPE_PRE) {
                Notifier.post(c, type, idx);
            } else if (type == Scheduler.TYPE_ALARM) {
                AdhanService.start(c, type, idx);
            }
        } catch (Exception ignored) {
        }
        WidgetProvider.refresh(c);
        Scheduler.scheduleNext(c);
    }
}
