package app.waqt.prayer;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

/** Typed access to the saved settings. */
final class Prefs {
    final SharedPreferences sp;

    Prefs(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("waqt", Context.MODE_PRIVATE);
    }

    String s(String k, String d) { return sp.getString(k, d); }
    int i(String k, int d) { return sp.getInt(k, d); }
    boolean b(String k, boolean d) { return sp.getBoolean(k, d); }
    void put(String k, String v) { sp.edit().putString(k, v).apply(); }
    void put(String k, int v) { sp.edit().putInt(k, v).apply(); }
    void put(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }
    void remove(String k) { sp.edit().remove(k).apply(); }

    /** Prayer alert on or off. Sunrise is off by default. */
    boolean alert(int k) { return b("al" + k, k != 1); }
    boolean silent(int k) { return b("si" + k, false); }
    int adj(int k) { return i("adj" + k, 0); }

    String exportJson() {
        JSONObject o = new JSONObject();
        try {
            for (Map.Entry<String, ?> e : sp.getAll().entrySet()) o.put(e.getKey(), e.getValue());
            o.put("app", "waqt");
        } catch (JSONException ignored) { }
        return o.toString();
    }

    boolean importJson(String text) {
        try {
            JSONObject o = new JSONObject(text);
            if (!"waqt".equals(o.optString("app"))) return false;
            SharedPreferences.Editor ed = sp.edit();
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String k = it.next();
                if (k.equals("app")) continue;
                Object v = o.get(k);
                if (v instanceof Boolean) ed.putBoolean(k, (Boolean) v);
                else if (v instanceof Integer) ed.putInt(k, (Integer) v);
                else if (v instanceof String) ed.putString(k, (String) v);
            }
            ed.apply();
            return true;
        } catch (JSONException e) {
            return false;
        }
    }
}
