package app.waqt.prayer;

/** Astronomical prayer time calculation. Returns minutes after local midnight, or Integer.MIN_VALUE when undefined. */
final class PrayerEngine {
    static final String[] KEYS = {"makkah", "mwl", "egypt", "karachi", "isna", "kuwait", "qatar", "dubai", "singapore", "turkey", "tehran"};
    static final String[] NAME_AR = {"أم القرى (مكة المكرمة)", "رابطة العالم الإسلامي", "الهيئة المصرية العامة للمساحة", "جامعة العلوم الإسلامية بكراتشي", "أمريكا الشمالية (ISNA)", "الكويت", "قطر", "الإمارات", "سنغافورة وماليزيا", "رئاسة الشؤون الدينية (تركيا)", "جامعة طهران"};
    static final String[] NAME_EN = {"Umm al-Qura (Makkah)", "Muslim World League", "Egyptian General Authority", "Univ. of Islamic Sciences, Karachi", "North America (ISNA)", "Kuwait", "Qatar", "UAE", "Singapore / Malaysia", "Diyanet (Turkey)", "Univ. of Tehran"};
    static final double[] FAJR = {18.5, 18, 19.5, 18, 15, 18, 18, 18.2, 20, 18, 17.7};
    static final double[] ISHA = {0, 17, 17.5, 18, 15, 17.5, 0, 18.2, 18, 17, 14};
    static final int[] ISHA_MIN = {90, 0, 0, 0, 0, 0, 90, 0, 0, 0, 0};
    static final double[] MAGHRIB = {Double.NaN, Double.NaN, Double.NaN, Double.NaN, Double.NaN, Double.NaN, Double.NaN, Double.NaN, Double.NaN, Double.NaN, 4.5};

    private static final double RAD = Math.PI / 180;

    private static double sin(double d) { return Math.sin(d * RAD); }
    private static double cos(double d) { return Math.cos(d * RAD); }
    private static double tan(double d) { return Math.tan(d * RAD); }
    private static double asin(double x) { return Math.asin(x) / RAD; }
    private static double acos(double x) { return Math.acos(x) / RAD; }
    private static double atan2(double y, double x) { return Math.atan2(y, x) / RAD; }
    private static double acot(double x) { return Math.atan(1 / x) / RAD; }
    private static double fixA(double a) { a = a - 360 * Math.floor(a / 360); return a < 0 ? a + 360 : a; }
    private static double fixH(double a) { a = a - 24 * Math.floor(a / 24); return a < 0 ? a + 24 : a; }

    private static double julian(int y, int m, int d) {
        if (m <= 2) { y -= 1; m += 12; }
        int a = y / 100, b = 2 - a + a / 4;
        return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524.5;
    }

    /** Returns {declination, equation of time}. */
    private static double[] sunPos(double jd) {
        double dd = jd - 2451545.0;
        double g = fixA(357.529 + 0.98560028 * dd);
        double q = fixA(280.459 + 0.98564736 * dd);
        double lm = fixA(q + 1.915 * sin(g) + 0.020 * sin(2 * g));
        double e = 23.439 - 0.00000036 * dd;
        double ra = atan2(cos(e) * sin(lm), cos(lm)) / 15;
        return new double[]{asin(sin(e) * sin(lm)), q / 15 - fixH(ra)};
    }

    static int methodIndex(String key) {
        for (int i = 0; i < KEYS.length; i++) if (KEYS[i].equals(key)) return i;
        return 0;
    }

    static int[] compute(int y, int m, int d, double lat, double lng, double tzH, boolean ramadan, Prefs p) {
        int mi = methodIndex(p.s("method", "makkah"));
        int asrFactor = p.i("asr", 1);
        String hl = p.s("hl", "angle");
        double fa = FAJR[mi];
        boolean ishaIsMinutes = ISHA[mi] == 0;
        double ishaAngle = ishaIsMinutes ? 0.833 : ISHA[mi];
        double maghribAngle = Double.isNaN(MAGHRIB[mi]) ? 0.833 : MAGHRIB[mi];
        double jd0 = julian(y, m, d) - lng / (15 * 24);

        // order: fajr, sunrise, dhuhr, asr, sunset, maghrib, isha
        double[] t = {5, 6, 12, 13, 18, 18, 18};
        for (int pass = 0; pass < 2; pass++) {
            double[] nt = new double[7];
            nt[0] = angleTime(jd0, lat, fa, t[0] / 24, true);
            nt[1] = angleTime(jd0, lat, 0.833, t[1] / 24, true);
            nt[2] = midDay(jd0, t[2] / 24);
            double dec = sunPos(jd0 + t[3] / 24)[0];
            nt[3] = angleTime(jd0, lat, -acot(asrFactor + tan(Math.abs(lat - dec))), t[3] / 24, false);
            nt[4] = angleTime(jd0, lat, 0.833, t[4] / 24, false);
            nt[5] = angleTime(jd0, lat, maghribAngle, t[5] / 24, false);
            nt[6] = angleTime(jd0, lat, ishaAngle, t[6] / 24, false);
            for (int i = 0; i < 7; i++) {
                if (!Double.isNaN(nt[i])) t[i] = nt[i];
                else if (pass == 1) t[i] = Double.NaN;
            }
        }
        double shift = tzH - lng / 15;
        for (int i = 0; i < 7; i++) t[i] += shift;

        if (!"none".equals(hl)) {
            double night = fixH(t[1] - t[4]);
            if (!Double.isNaN(night)) {
                double pf = portion(hl, fa);
                if (Double.isNaN(t[0]) || (t[1] - t[0] > pf * night)) t[0] = t[1] - pf * night;
                if (!ishaIsMinutes) {
                    double pi = portion(hl, ISHA[mi]);
                    if (Double.isNaN(t[6]) || (t[6] - t[4] > pi * night)) t[6] = t[4] + pi * night;
                }
            }
        }
        if (ishaIsMinutes) {
            int add = (ramadan && mi == 0) ? 120 : ISHA_MIN[mi];
            t[6] = t[5] + add / 60.0;
        }
        double[] v = {t[0], t[1], t[2], t[3], t[5], t[6]};
        int[] out = new int[6];
        for (int k = 0; k < 6; k++) {
            if (Double.isNaN(v[k])) { out[k] = Integer.MIN_VALUE; continue; }
            int base = (k == 1 || k == 2) ? (int) Math.round(v[k] * 60) : (int) Math.floor(v[k] * 60 + 1e-6);
            out[k] = base + p.adj(k);
        }
        return out;
    }

    private static double portion(String hl, double angle) {
        if ("mid".equals(hl)) return 0.5;
        if ("seventh".equals(hl)) return 1.0 / 7;
        return angle / 60;
    }

    private static double midDay(double jd0, double t) {
        return fixH(12 - sunPos(jd0 + t)[1]);
    }

    private static double angleTime(double jd0, double lat, double angle, double t, boolean ccw) {
        double dec = sunPos(jd0 + t)[0];
        double noon = midDay(jd0, t);
        double v = (-sin(angle) - sin(dec) * sin(lat)) / (cos(dec) * cos(lat));
        if (v > 1 || v < -1) return Double.NaN;
        double x = acos(v) / 15;
        return noon + (ccw ? -x : x);
    }

    static double qiblaBearing(double lat, double lng) {
        double dl = (39.8262 - lng) * RAD, p1 = lat * RAD, p2 = 21.4225 * RAD;
        return fixA(Math.atan2(Math.sin(dl), Math.cos(p1) * Math.tan(p2) - Math.sin(p1) * Math.cos(dl)) / RAD);
    }

    static double distanceKm(double lat, double lng) {
        double dp = (21.4225 - lat) * RAD, dl = (39.8262 - lng) * RAD;
        double a = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(lat * RAD) * Math.cos(21.4225 * RAD) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }
}
