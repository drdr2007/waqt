package app.waqt.prayer;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.chrono.HijrahDate;
import java.time.temporal.ChronoField;
import java.util.TimeZone;

/** Resolves the active location and builds one day of prayer times. */
final class Times {
    static final class Loc {
        String name;
        double lat, lng;
        String tz;
    }

    static final class Day {
        LocalDate date;
        int[] mins = new int[6];
        long[] ms = new long[6];
        int hy, hm, hd;
        boolean ramadan;
        double tzH;
        String key;
    }

    static final class Np {
        int k;
        long ms;
        Day day;
    }

    static Loc loc(Prefs p) {
        Loc l = new Loc();
        if (p.b("gps", false)) {
            l.name = p.s("locName", Tx.L("موقعي", "My location"));
            try {
                l.lat = Double.parseDouble(p.s("lat", "21.4225"));
                l.lng = Double.parseDouble(p.s("lng", "39.8262"));
            } catch (NumberFormatException e) {
                l.lat = 21.4225;
                l.lng = 39.8262;
            }
            l.tz = TimeZone.getDefault().getID();
        } else {
            String[] c = Cities.find(p.s("cityId", "riyadh"));
            l.name = Tx.ar ? c[1] : c[2];
            l.lat = Double.parseDouble(c[3]);
            l.lng = Double.parseDouble(c[4]);
            l.tz = c[5];
        }
        return l;
    }

    static int[] hijri(LocalDate d, int adj) {
        try {
            HijrahDate h = HijrahDate.from(d.plusDays(adj));
            return new int[]{h.get(ChronoField.YEAR), h.get(ChronoField.MONTH_OF_YEAR), h.get(ChronoField.DAY_OF_MONTH)};
        } catch (Exception e) {
            return new int[]{0, 1, 1};
        }
    }

    static Day day(Prefs p, int off) {
        Loc l = loc(p);
        LocalDate today = LocalDate.now(ZoneId.of(l.tz));
        return forDate(p, l, today.plusDays(off));
    }

    static Day forDate(Prefs p, Loc l, LocalDate d) {
        Day r = new Day();
        r.date = d;
        r.key = d.toString();
        long dayMs = d.toEpochDay() * 86400000L;
        r.tzH = TimeZone.getTimeZone(l.tz).getOffset(dayMs + 9 * 3600000L) / 3600000.0;
        int[] h = hijri(d, p.i("hAdj", 0));
        r.hy = h[0];
        r.hm = h[1];
        r.hd = h[2];
        r.ramadan = h[1] == 9;
        r.mins = PrayerEngine.compute(d.getYear(), d.getMonthValue(), d.getDayOfMonth(), l.lat, l.lng, r.tzH, r.ramadan, p);
        for (int k = 0; k < 6; k++) {
            r.ms[k] = r.mins[k] == Integer.MIN_VALUE ? Long.MIN_VALUE : dayMs + Math.round((r.mins[k] / 60.0 - r.tzH) * 3600000.0);
        }
        return r;
    }

    /** Next prayer (never sunrise) after now; prev is the one before it. */
    static Np[] nextAndPrev(Prefs p, long now) {
        Np next = null, prev = null;
        int[] ks = {0, 2, 3, 4, 5};
        for (int off = -1; off <= 2 && next == null; off++) {
            Day d = day(p, off);
            for (int k : ks) {
                if (d.ms[k] == Long.MIN_VALUE) continue;
                Np e = new Np();
                e.k = k;
                e.ms = d.ms[k];
                e.day = d;
                if (e.ms > now) { next = e; break; }
                prev = e;
            }
        }
        return new Np[]{next, prev};
    }

    static String countdown(long ms) {
        long s = Math.max(0, ms / 1000);
        return Tx.n(Tx.two((int) (s / 3600)) + ":" + Tx.two((int) (s % 3600 / 60)) + ":" + Tx.two((int) (s % 60)));
    }
}
