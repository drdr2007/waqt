package app.waqt.prayer;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.time.LocalTime;

/** Full screen Fajr alarm shown over the lock screen with Snooze and Stop. */
public class AlarmActivity extends Activity {
    private final BroadcastReceiver ended = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            finish();
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Prefs p = new Prefs(this);
        Tx.init(p);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF18382F, 0xFF0E2119});
        root.setBackground(bg);
        root.setLayoutDirection(Tx.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);

        TextView title = text("sahoor".equals(p.s("alType", "fajr")) ? Tx.L("وقت السحور", "Sahoor time") : Tx.L("استيقظ! اقترب الفجر", "Wake up! Fajr is near"), 30, 0xFFF3F6F0, true);
        Times.Day d = Times.day(p, 0);
        TextView sub = text(Tx.pr(0) + " " + Tx.clock(d.mins[0]), 18, 0xFFE0B43A, false);
        LocalTime now = LocalTime.now();
        TextView clock = text(Tx.clock(now.getHour() * 60 + now.getMinute()), 54, 0xFFF3F6F0, false);
        root.addView(title);
        root.addView(sub);
        root.addView(clock);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, dp(40), 0, 0);
        row.addView(button(Tx.L("غفوة", "Snooze") + " " + Tx.n(p.i("alSnooze", 5)) + " " + Tx.L("د", "min"), 0x33FFFFFF, 0xFFF3F6F0, AdhanService.ACT_SNOOZE));
        row.addView(button(Tx.L("إيقاف", "Stop"), 0xFFE0B43A, 0xFF1A1405, AdhanService.ACT_STOP));
        root.addView(row);
        setContentView(root);
        IntentFilter f = new IntentFilter("app.waqt.prayer.ALARM_ENDED");
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(ended, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(ended, f);
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        t.setPadding(0, dp(6), 0, dp(6));
        return t;
    }

    private TextView button(String label, int bg, int fg, final String action) {
        TextView t = text(label, 18, fg, true);
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(16));
        t.setBackground(g);
        t.setPadding(dp(24), dp(16), dp(24), dp(16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(8), 0, dp(8), 0);
        t.setLayoutParams(lp);
        t.setOnClickListener(v -> {
            startService(new Intent(this, AdhanService.class).setAction(action));
            finish();
        });
        return t;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(ended); } catch (Exception ignored) { }
        super.onDestroy();
    }
}
