package app.waqt.prayer;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;

/** Opens the chosen audio file, or the built-in chime when none is set or it cannot be read. */
final class Sound {
    private static AudioAttributes attrs(boolean alarm) {
        return new AudioAttributes.Builder()
            .setUsage(alarm ? AudioAttributes.USAGE_ALARM : AudioAttributes.USAGE_MEDIA)
            .setContentType(alarm ? AudioAttributes.CONTENT_TYPE_SONIFICATION : AudioAttributes.CONTENT_TYPE_MUSIC)
            .build();
    }

    /** slot is "adhan", "fajr" or "alarm". Returns a prepared player or null. */
    static MediaPlayer open(Context c, Prefs p, String slot, boolean loop, boolean alarmUsage) {
        MediaPlayer mp = new MediaPlayer();
        try {
            mp.setAudioAttributes(attrs(alarmUsage));
            String u = p.s("snd_" + slot, "");
            boolean ok = false;
            if (!u.isEmpty()) {
                try {
                    mp.setDataSource(c, Uri.parse(u));
                    ok = true;
                } catch (Exception e) {
                    mp.reset();
                    mp.setAudioAttributes(attrs(alarmUsage));
                }
            }
            if (!ok) {
                AssetFileDescriptor afd = c.getResources().openRawResourceFd(R.raw.chime);
                mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                afd.close();
            }
            mp.setLooping(loop);
            float v = Math.max(0.05f, p.i("vol", 80) / 100f);
            mp.setVolume(v, v);
            mp.prepare();
            return mp;
        } catch (Exception e) {
            try { mp.release(); } catch (Exception ignored) { }
            return null;
        }
    }

    static String slotFor(Prefs p, int type, int idx) {
        if (type == Scheduler.TYPE_ALARM) return "alarm";
        if (idx == 0 && !p.s("snd_fajr", "").isEmpty()) return "fajr";
        return "adhan";
    }
}
