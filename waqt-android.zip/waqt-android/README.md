# Waqt - مواقيت الصلاة (Android)

Native Android prayer times app: adhan and notifications in the background, Fajr alarm, re-scheduling after reboot, home screen widget, Qibla compass, Hijri calendar and converter, backup and restore. Java, no third-party libraries.

## Get the APK
1. Push this folder to a GitHub repository (branch `main`).
2. Open the **Actions** tab, run **Build APK** (it also runs on every push).
3. When it finishes, open **Releases** > **Waqt latest APK** and download `app-release.apk`.
4. Open the file on your phone and allow installing from this source.

## First run on the phone
- Allow notifications.
- Settings > Alert readiness: allow exact alarms and exempt the app from battery optimization.
- Pick your city or tap "Use GPS".
- Choose your adhan audio file under Notification settings (a chime is used if none is chosen).
